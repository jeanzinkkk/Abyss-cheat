package com.abyssclient.mobile;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.net.Uri;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        web.setBackgroundColor(0xFF090610);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(false);
        web.addJavascriptInterface(new Bridge(), "Abyss");
        web.setWebViewClient(new WebViewClient());
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private class Bridge {
        @JavascriptInterface
        public void launchMinecraft() {
            runOnUiThread(() -> {
                Intent launch = getPackageManager().getLaunchIntentForPackage("com.mojang.minecraftpe");
                if (launch == null) {
                    Toast.makeText(MainActivity.this, "Minecraft não encontrado. Instale pela Play Store.", Toast.LENGTH_LONG).show();
                    return;
                }
                try { startActivity(launch); }
                catch (ActivityNotFoundException e) {
                    Toast.makeText(MainActivity.this, "Não foi possível abrir o Minecraft.", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void importAddonHelp() {
            runOnUiThread(() -> Toast.makeText(MainActivity.this,
                "Para importar um .mcaddon, abra o arquivo no Android e escolha Minecraft.",
                Toast.LENGTH_LONG).show());
        }
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
